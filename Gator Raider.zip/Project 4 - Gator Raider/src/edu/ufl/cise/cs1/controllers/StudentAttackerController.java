package edu.ufl.cise.cs1.controllers;
import game.controllers.AttackerController;
import game.models.*;

public final class StudentAttackerController implements AttackerController {
	public void init(Game game) {
	}

	public void shutdown(Game game) {
	}

	public int update(Game game, long timeDue) {
		// * Setting variables:
		// Initialize action as = -1
		int action = -1;

		// Set variables to find the closest defender, their location, and their distance from the player.
		Defender closestDefender = (Defender) game.getAttacker().getTargetActor(game.getDefenders(), true);
		Node closestDefenderLocation = closestDefender.getLocation();
		int closestDefenderDistance = game.getAttacker().getLocation().getPathDistance(closestDefenderLocation);

		// Initialize variables to find the locations of the closest regular and power pills.
		Node closestPowerPill = null;
		Node closestPill = null;

		// Set the values for closestPill and closestPowerPill ONLY if there are pills and power pills left to get
		if (!game.getPowerPillList().isEmpty()) {
			closestPowerPill = game.getAttacker().getTargetNode(game.getPowerPillList(), true);
		}
		if (!game.getPillList().isEmpty()) {
			closestPill = game.getAttacker().getTargetNode(game.getPillList(), true);
		}


		// * Start of AI commands:
		// Pursue nearby vulnerable defenders in order of closeness
		if (closestDefender.isVulnerable()) {
			action = game.getAttacker().getNextDir(closestDefenderLocation, true);
			return action;
		}

		// Move to the closest power pill, then wait until enemies are nearby, then grab the pill so can pursue vulnerable defenders.
		if (!game.getPowerPillList().isEmpty()) {
			// If statement to get close to power pill and grab it if enemy is nearby
			if (!closestDefender.isVulnerable() && game.getAttacker().getLocation().getPathDistance(closestDefenderLocation) <= 20 && game.getAttacker().getLocation().getPathDistance(closestPowerPill) <= 10) {
				action = game.getAttacker().getNextDir(closestPowerPill, true);
				return action;
			// Else if statement to halt in front of a power pill if enemies are not close
			} else if (game.getAttacker().getLocation().getPathDistance(closestPowerPill) <= 5) {
				action = game.getAttacker().getReverse();
				return action;
			}
		}

		// Flee from very close enemies
		if (closestDefenderDistance <= 5) {
			action = game.getAttacker().getNextDir(closestDefenderLocation, false);
			return action;
		}

		// Move to next power pill until there are none left, generally.
		if (!game.getPowerPillList().isEmpty()) {
			action = game.getAttacker().getNextDir(closestPowerPill, true);
			return action;
		}

		// If there are no more power pills, only pursue regular.
		if (!game.getPillList().isEmpty()) {
			action = game.getAttacker().getNextDir(closestPill, true);
		}
		else {
			action = game.getAttacker().getReverse();
		}
		return action;
	}
}

// * Big thanks to the TAs Kendell Willis and Andrew Penton for helping me to complete and optimize my code during office hours,
// * particularly regarding the code for collecting power pills in relation to enemy distance.
// * The TA video tutorial on this project also gave me good place to start my work.
// * Otherwise, all work for this project was my own.